pVerify Wordpress Plugin version 1.0

Robert Dejournett, PhD
rob.dejournett@pverify.com

This plugin is designed to be used in conjunction with pVerify for access to our Estimator Widget.  You will need an account with pVerify as a medical provider (with valid NPI) to use this service.  Once your account is active, you can use this plugin. 

Use:

You will need to obtain the ID/secret from pVerify and add it to the plugin interface.

Then you can use the plugin shortcode anywhere in Wordpress to expose the pVerify Estimator Widget.  This allow you to collect patient name, DOB, member ID, payer name, and type of lab test, and submit insurance verification and calcualte expected patient cost of test.  Additionally you can add a email and/or webhook on the pVerify side to capture the outbound data that the user enters to connect to your CRM or other software systems.

Please contact us for further information.   support@pverify.com

Thank you
